package com.safetracehub.coolstories;

/**
 * Created by SafeTraceHub on 31-03-2018.
 */

public class storyList {
    private String s1, s2, s3;
    public storyList(String string, String string1, String string2) {
        this.s1 = string;
        this.s2 = string1;
        this.s3 = string2;
    }

    public String getS1() {
        return s1;
    }

    public void setS1(String s1) {
        this.s1 = s1;
    }

    public String getS2() {
        return s2;
    }

    public void setS2(String s2) {
        this.s2 = s2;
    }

    public String getS3() {
        return s3;
    }

    public void setS3(String s3) {
        this.s3 = s3;
    }
}
