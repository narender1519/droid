package com.safetracehub.coolstories;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StoryWrite extends AppCompatActivity {

    DatabaseHelper database;
    EditText textWriter,hWriter;
    Button sButton;
    int currentLengthheading;
    String heading,story,mUser,mPass;
    String[] sLength,hLength;
    String[] textarray;
    TextView wCount;

    DateFormat time = new SimpleDateFormat("hh:mm:ss a");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_write);
        textWriter = findViewById(R.id.writer);
        hWriter = findViewById(R.id.hWriter);
        //button = findViewById(R.id.save);
        sButton = findViewById(R.id.save);
        wCount = findViewById(R.id.wordCount);

        mUser= getIntent().getStringExtra("USER");
        mPass = getIntent().getStringExtra("PASS");

        heading = getIntent().getStringExtra("HEADING");
        story = getIntent().getStringExtra("STORY");


        final String cTime = time.format(new Date()).toString();
        Log.e("ime-->", String.valueOf(cTime));


        String stStory = story;
        stStory = stStory.replace("\n", " ");
        sLength = stStory.split(" ");

        String stHeading = heading;
        stHeading = stHeading.replace("\n", " ");
        hLength = stHeading.split(" ");

        database = new DatabaseHelper(this);

        hWriter.setText(heading);
        hWriter.setSelection(heading.length());

        textWriter.setText(story);
        textWriter.setSelection(story.length());
        wCount.setText(String.valueOf(sLength.length));

        hWriter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = hWriter.getText().toString();
                text = text.replace("\n", " ");
                String[] textarray = text.split(" ");
                //Log.e("words---->", String.valueOf(textarray.length));
                if (textarray.length == hLength.length) {
                    try {
                        //Log.e("count", String.valueOf(currentLength));
                        InputFilter[] FilterArray = new InputFilter[1];
                        FilterArray[0] = new InputFilter.LengthFilter(currentLengthheading);
                        hWriter.setFilters(FilterArray);
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }

                if (s.toString().length() < heading.length()) {
                    hWriter.setText(heading);
                    hWriter.setSelection(heading.length());
                }

                String result = s.toString().replaceAll("  ", "");
                if (!s.toString().equals(result)) {
                    hWriter.setText(result);
                    hWriter.setSelection(result.length());
                }

            }

            @Override
            public void afterTextChanged(Editable s) {
                String currentText = s.toString();
                currentLengthheading = currentText.length();
                Log.e("count", String.valueOf(currentText));
            }
        });

        textWriter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = textWriter.getText().toString();
                text = text.replace("\n", " ");
                String[] textarray = text.split(" ");
                Log.e("xCount-->", String.valueOf(textarray.length));
                wCount.setText(String.valueOf(textarray.length));
                if (textarray.length == sLength.length+50) {
                    AlertDialog alertDialog = new AlertDialog.Builder(StoryWrite.this).create();
                    alertDialog.setMessage("You have entered 50 words");
                    alertDialog.show();
                    InputFilter filter = new InputFilter() {
                        public CharSequence filter(CharSequence source, int start, int end,
                                                   Spanned dest, int dstart, int dend) {
                            for (int i = start; i < end; i++) {
                                if (!Character.isLetterOrDigit(source.charAt(i))) {
                                    return "";
                                }
                            }
                            return null;
                        }
                    };
                    textWriter.setFilters(new InputFilter[] { filter });
                }

                /*
                * Story has 500 words
                * */

                if (textarray.length == 500) {
                    AlertDialog alertDialog = new AlertDialog.Builder(StoryWrite.this).create();
                    alertDialog.setMessage("You have entered 500 words");
                    alertDialog.show();
                    InputFilter filter = new InputFilter() {
                        public CharSequence filter(CharSequence source, int start, int end,
                                                   Spanned dest, int dstart, int dend) {
                            for (int i = start; i < end; i++) {
                                if (!Character.isLetterOrDigit(source.charAt(i))) {
                                    return "";
                                }
                            }
                            return null;
                        }
                    };
                    textWriter.setFilters(new InputFilter[] { filter });
                }

                if (s.toString().length() < story.length()) {
                    textWriter.setText(story);
                    textWriter.setSelection(story.length());
                }

                String result = s.toString().replaceAll("  ", "");
                if (!s.toString().equals(result)) {
                    textWriter.setText(result);
                    textWriter.setSelection(result.length());
                }

            }

            @Override
            public void afterTextChanged(Editable s) {
                /*String currentText = s.toString();
                currentLengthstory = currentText.length();
                Log.e("count", String.valueOf(currentText));*/
            }
        });


        sButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getId = database.getID(mUser,mPass);
                database.addIdHeading(getId, heading);
                update(hWriter.getText().toString(),textWriter.getText().toString(),cTime);
                startActivity(new Intent(StoryWrite.this, ShowData.class));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.logout,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if(id==R.id.logout) {
            startActivity(new Intent(StoryWrite.this, MainActivity.class));
        }
        return false;
    }

    public void update(String heading, String story, String ctime){
        boolean upYes = database.updateData(heading,story, ctime);
        if(upYes==true){
            Intent intent = new Intent(StoryWrite.this, ShowData.class);
            intent.putExtra("USER", mUser);
            intent.putExtra("PASS", mPass);
            startActivity(intent);
            Toast.makeText(this, "successfully updated", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "not updated", Toast.LENGTH_LONG).show();
        }
    }

}
