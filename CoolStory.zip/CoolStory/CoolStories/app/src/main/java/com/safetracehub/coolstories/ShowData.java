package com.safetracehub.coolstories;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ShowData extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    ListView listView;
    String mUser,mPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data);
        listView = findViewById(R.id.dataView);

        databaseHelper = new DatabaseHelper(this);

        mUser= getIntent().getStringExtra("USER");
        mPass = getIntent().getStringExtra("PASS");

        final ArrayList<storyList> theList = new ArrayList<>();
        final ArrayList<storyList> theList1 = new ArrayList<>();
        Cursor data = databaseHelper.getListContents();
        if(data.getCount() == 0){
            Toast.makeText(this, "Sorry, No Stories are found", Toast.LENGTH_LONG).show();
        }else{
            while(data.moveToNext()) {
                final storyList storyList = new storyList(data.getString(1), data.getString(2), data.getString(3));
                theList.add(storyList);
            }
            for(int i=theList.size()-1;i>=0;i--) {
                theList1.add(theList.get(i));
            }
                StoriesAdapter storiesAdapter = new StoriesAdapter(ShowData.this, R.layout.activity_stories_adapter,theList1);
                listView.setAdapter(storiesAdapter);

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        try {
                            boolean wrote = databaseHelper.checkWrote(databaseHelper.getID(mUser, mPass), theList1.get(position).getS1());
                            Log.e("wrote", String.valueOf(wrote));
                            if (wrote == true) {
                                AlertDialog alertDialog = new AlertDialog.Builder(ShowData.this).create();
                                alertDialog.setMessage("You already wrote the story");
                                alertDialog.show();
                            } else {
                                Intent intent = new Intent(ShowData.this, StoryWrite.class);
                                intent.putExtra("HEADING", theList1.get(position).getS1());
                                intent.putExtra("STORY", theList1.get(position).getS2());
                                intent.putExtra("USER", mUser);
                                intent.putExtra("PASS", mPass);
                                startActivity(intent);
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                });
            }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.logout,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if(id==R.id.logout) {
            startActivity(new Intent(ShowData.this, MainActivity.class));
        }
        return false;
    }
}
