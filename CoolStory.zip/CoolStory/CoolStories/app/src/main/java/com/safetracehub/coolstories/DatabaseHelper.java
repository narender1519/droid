package com.safetracehub.coolstories;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by STH-NB-MICRO-004 on 01-11-2017.
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "database.db";
    public static final String TABLE_NAME = "database_data";
    public static final String LOGINTABLE= "LoginData_data";
    public static final String IDHEADING= "idHeading";
    public static final String COL1 = "ID";
    public static final String COL2 = "ITEM1";
    public static final String COL3 = "ITEM2";
    public static final String COL4 = "ITEM3";
    public static final String COL5 = "ITEM4";
    public static final String TIME = "TIME";
    public static final String GETID = "GETID";
    public static final String HEADING = "HEADING";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        final String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ITEM1 TEXT," + "ITEM2 TEXT,"+ "TIME TEXT)";
        final String LoginTable = "CREATE TABLE " + LOGINTABLE + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ITEM3 TEXT," + "ITEM4 TEXT)";
        final String getId = "CREATE TABLE " + IDHEADING + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "GETID TEXT," + "HEADING TEXT)";
        db.execSQL(createTable);
        db.execSQL(LoginTable);
        db.execSQL(getId);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP IF TABLE EXISTS " + TABLE_NAME);
        db.execSQL("DROP IF TABLE EXISTS " + LOGINTABLE);
        db.execSQL("DROP IF TABLE EXISTS " + IDHEADING);
        onCreate(db);
    }

    public boolean addData(String item1, String item2, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, item1);
        contentValues.put(COL3, item2);
        contentValues.put(TIME, time);

        long result = db.insert(TABLE_NAME, null, contentValues);

        //if date as inserted incorrectly it will return -1
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public boolean AddLogin(String item3, String item4) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL4, item3);
        contentValues.put(COL5, item4);

        long result = db.insert(LOGINTABLE, null, contentValues);

        //if date as inserted incorrectly it will return -1
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean addIdHeading(String item3, String item4) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(GETID, item3);
        contentValues.put(HEADING, item4);

        long result = db.insert(IDHEADING, null, contentValues);

        //if date as inserted incorrectly it will return -1
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor getListContents(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        return data;
    }

    public Cursor getLoginContents(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + LOGINTABLE, null);
        return data;
    }
    public String getID(String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + LOGINTABLE, null);
        String a, b;
        String c=null;
        if(data.moveToFirst()){
            do{
                a = data.getString(1);
                b = data.getString(2);
                Log.e("a---->", a);
                Log.e("b---->", b);
                if(a.equals(email) && b.equals(password)){
                    c=data.getString(0);
                    break;
                }
            }while(data.moveToNext());
        }
        return c;
    }

    public Cursor checkUser1(String email) {

        // array of columns to fetch
        String[] columns = {
                COL2,COL3
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COL2 + " = ?";

        // selection argument
        String[] selectionArgs = {email};

        // query user table with condition
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE user_email = 'jack@androidtutorialshub.com';
         */
        Cursor cursor = db.query(TABLE_NAME, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return cursor;
        }
        return null;
        //return false;
    }

    public void deleteAll(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = getListContents();
        //long rowId = c.getColumnIndexOrThrow(COL1);
        if(c.moveToFirst()){
            do {
                db.delete(TABLE_NAME,COL1,null);
            }while (c.moveToNext());
        }
        c.close();
    }

    public  boolean updateData(String item1, String item2, String time){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, item1);
        contentValues.put(COL3, item2);
        contentValues.put(TIME, time);
        db.update(TABLE_NAME,  contentValues,"ITEM1 = ?", new String[]{item1});
        return true;
    }

    public Boolean checkUser(String email, String password) {

        // array of columns to fetch
        String[] columns = {
                COL1
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COL4 + " = ?" + " AND " + COL5 + " = ?";

        // selection arguments
        String[] selectionArgs = {email, password};

        // query user table with conditions
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE user_email = 'jack@androidtutorialshub.com' AND user_password = 'qwerty';
         */
        Cursor cursor = db.query(LOGINTABLE, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);  //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public Boolean checkWrote(String id, String heading) {

        String[] columns = {
                COL1
        };
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = GETID + " = ?" + " AND " + HEADING + " = ?";

        String[] selectionArgs = {id, heading};

        // query user table with conditions
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE ID = 'userID' AND HEADING = 'heading';
         */
        Cursor cursor = db.query(IDHEADING, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);  //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }
}
