package com.safetracehub.coolstories;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;

public class Login extends AppCompatActivity {

    Button nStory,upStory,searchButton;
    DatabaseHelper databaseHelper;
    private ShowData showData;
    String mUser,mPass;
    AutoCompleteTextView search;
    ArrayList<storyList> theList = new ArrayList<>();
    ArrayList<String> theList1 = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        search = findViewById(R.id.seachText);

        mUser= getIntent().getStringExtra("USER");
        mPass = getIntent().getStringExtra("PASS");

        nStory = findViewById(R.id.newStory);
        upStory = findViewById(R.id.upStory);
        searchButton = findViewById(R.id.seachButton);

        databaseHelper = new DatabaseHelper(this);
        Cursor data = databaseHelper.getListContents();

        search.setVisibility(View.GONE);

        if(data.getCount() == 0){
           // Toast.makeText(this, "Sorry, No Stories are found", Toast.LENGTH_LONG).show();
        }else {
            while (data.moveToNext()) {
                final storyList storyList = new storyList(data.getString(1), data.getString(2), data.getString(3));
                theList.add(storyList);
                theList1.add(storyList.getS1());
            }

            search.setAdapter(new ArrayAdapter<String>(Login.this, android.R.layout.simple_list_item_1, theList1));
        }

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search.setVisibility(View.VISIBLE);
                searchButton.setVisibility(View.GONE);
            }
        });

        search.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                search.showDropDown();
            }
        });

        /*
        * search functiona;ity here when search and click the item it open story board
        * */
        search.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.e("item",theList1.get(position));
                    Log.e("list---->",theList.get(position).getS2());
                Intent intent = new Intent(Login.this, StoryWrite.class);
                intent.putExtra("HEADING", theList.get(position).getS1());
                intent.putExtra("STORY", theList.get(position).getS2());
                startActivity(intent);
            }
        });

        nStory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this, NewStroy.class);
                intent.putExtra("USER", mUser);
                intent.putExtra("PASS", mPass);
                startActivity(intent);
                //startActivity(new Intent(Login.this, NewStroy.class));
            }
        });

        upStory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this, ShowData.class);
                intent.putExtra("USER", mUser);
                intent.putExtra("PASS", mPass);
                startActivity(intent);
                //startActivity(new Intent(Login.this, ShowData.class));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.logout,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if(id==R.id.logout) {
            startActivity(new Intent(Login.this, MainActivity.class));
        }
        return false;
    }


    /*public void newLogin(String entry, String hello){
        boolean lYes = databaseHelper.checkUser(entry,hello);
        if(lYes==true){
            startActivity(new Intent(Login.this, NewStroy.class));
            Toast.makeText(this, "yes", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "not", Toast.LENGTH_LONG).show();
        }
    }*/

    /*public void upLogin(String entry, String hello){
        boolean lYes = databaseHelper.checkUser(entry,hello);
        if(lYes==true){
            startActivity(new Intent(Login.this, NewStroy.class));
            Toast.makeText(this, "yes", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "not", Toast.LENGTH_LONG).show();
        }
    }

    public void Login(String entry, String hello){
        boolean lYes = databaseHelper.checkUser(entry,hello);
        if(lYes==true){
            startActivity(new Intent(Login.this, NewStroy.class));
            Toast.makeText(this, "yes", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "not", Toast.LENGTH_LONG).show();
        }
    }

    public void addLogin(String entry, String hello){
        boolean insertData = databaseHelper.AddLogin(entry,hello);
        if(insertData==true){
            Toast.makeText(this, "Inserted", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "not Inserted", Toast.LENGTH_LONG).show();
        }
    }

    *//*public void update(String entry, String hello){
        boolean insertData = database.updateData(entry,hello);
        if(insertData==true){
            Toast.makeText(this, "updated", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "not updated", Toast.LENGTH_LONG).show();
        }
    }*/
}
