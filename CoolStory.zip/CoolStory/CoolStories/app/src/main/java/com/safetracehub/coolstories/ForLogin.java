package com.safetracehub.coolstories;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ForLogin extends AppCompatActivity {

    EditText user,pass;
    Button login;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_for_login);
        user = findViewById(R.id.userName);
        pass = findViewById(R.id.userPass);
        login = findViewById(R.id.login);

        databaseHelper = new DatabaseHelper(this);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addLogin(user.getText().toString(),pass.getText().toString());
            }
        });
    }

    /*
    * here goes login*/
    public void addLogin(String user, String pass){

        //Log.e("---->", entry+"---->"+hello);
        boolean insertData = databaseHelper.checkUser(user,pass);
        if(insertData==true){
            Intent intent = new Intent(ForLogin.this, Login.class);
            intent.putExtra("USER", user);
            intent.putExtra("PASS", pass);
            startActivity(intent);
            Toast.makeText(this, "Successfully logged in", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "Username or password wrong", Toast.LENGTH_LONG).show();
        }
    }
}
