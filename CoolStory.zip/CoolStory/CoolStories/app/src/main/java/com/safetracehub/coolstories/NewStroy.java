package com.safetracehub.coolstories;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NewStroy extends AppCompatActivity {

    DatabaseHelper database;
    EditText textWriter,hWriter;
    Button saveStory;
    int count=0;
    String cTime,mUser, mPass;
    TextView wCount;

    DateFormat time = new SimpleDateFormat("hh:mm:ss a");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_stroy);

        hWriter = findViewById(R.id.hWriter);
        textWriter = findViewById(R.id.writer);
        saveStory = findViewById(R.id.save);
        wCount = findViewById(R.id.wordCount);

        mUser= getIntent().getStringExtra("USER");
        mPass = getIntent().getStringExtra("PASS");

        database = new DatabaseHelper(this);
        cTime = time.format(new Date()).toString();

        textWriter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //
            }
            /*
            * this allows max 50 words
            * */
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = textWriter.getText().toString();
                text = text.replace("\n", " ");
                String[] textarray = text.split(" ");
                Log.e("words---->", String.valueOf(textarray.length));
                wCount.setText(String.valueOf(textarray.length));
                if (textarray.length == 50) {
                    AlertDialog alertDialog = new AlertDialog.Builder(NewStroy.this).create();
                    alertDialog.setMessage("You entered 50 words");
                    alertDialog.show();
                    wCount.setText(String.valueOf(textarray.length));
                    InputFilter filter = new InputFilter() {
                        public CharSequence filter(CharSequence source, int start, int end,
                                                   Spanned dest, int dstart, int dend) {
                            for (int i = start; i < end; i++) {
                                if (!Character.isLetterOrDigit(source.charAt(i))) {
                                    return "";
                                }
                            }
                            return null;
                        }
                    };
                    textWriter.setFilters(new InputFilter[] { filter });
                }

                /*
                * if enters two spaces it wont allow
                * */
                String result = s.toString().replaceAll("  ", "");
                if (!s.toString().equals(result)) {
                    textWriter.setText(result);
                    textWriter.setSelection(result.length());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                /*String currentText = s.toString();
                currentLength = currentText.length();
                Log.e("count", String.valueOf(currentText));*/
            }
        });

        saveStory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(hWriter.getText().toString())){
                    Toast.makeText(NewStroy.this, "Please enter heading!", Toast.LENGTH_SHORT).show();
                }else if(TextUtils.isEmpty(textWriter.getText().toString())){
                    Toast.makeText(NewStroy.this, "Story is Empty!", Toast.LENGTH_SHORT).show();
                }else {
                    Inserting(hWriter.getText().toString(), textWriter.getText().toString(), cTime);
                    Log.d("count=>", String.valueOf(count));
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.logout,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if(id==R.id.logout) {
            startActivity(new Intent(NewStroy.this, MainActivity.class));
        }
        return false;
    }


    public void Inserting(String heading, String story,String time){
        /*
        * get ID with for this
        * */
        String getId = database.getID(mUser,mPass);
        /*
        * for inserting user id and heading of the story
        * */
        database.addIdHeading(getId, heading);

        /*story storing into data base with time of saving*/
        boolean insertData = database.addData(heading, story, time);
        if(insertData==true){
            Intent intent = new Intent(NewStroy.this, ShowData.class);
            intent.putExtra("USER", mUser);
            intent.putExtra("PASS", mPass);
            startActivity(intent);
            //startActivity(new Intent(NewStroy.this, ShowData.class));
            Toast.makeText(this, "Saved the story successfully", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show();
        }
    }
}
