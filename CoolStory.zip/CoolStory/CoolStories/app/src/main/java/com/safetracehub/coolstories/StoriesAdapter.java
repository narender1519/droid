package com.safetracehub.coolstories;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class StoriesAdapter extends ArrayAdapter<storyList> {
    private Context mContext;
    int mResource;

    public StoriesAdapter(@NonNull Context context, int resource, @NonNull ArrayList<storyList> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //String date = getItem(position).getDate();
        String s1 = getItem(position).getS1();
        String s2 = getItem(position).getS2();
        String s3 = getItem(position).getS3();
        //String status = getItem(position).getStatus();

        //Log.e("labe", label);
        //String Status = getItem(position).getStatus();

        //ProblemReportList problemReportList = new ProblemReportList(label, traceKey, status);
        storyList storyList = new storyList(s1, s2, s3);
        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        //TextView tvdate = (TextView) convertView.findViewById(R.id.textView1);
        TextView Label1 = (TextView) convertView.findViewById(R.id.textView);
        TextView Label2 = (TextView) convertView.findViewById(R.id.textView2);
        TextView Label3 = (TextView) convertView.findViewById(R.id.textView3);
        //TextView status1 = (TextView) convertView.findViewById(R.id.statusAdapter);

        //tvdate.setText(date);
        Label1.setText(s1);
        Label2.setText(s2);
        Label3.setText(s3);
        //status1.setText(status);

        return convertView;

    }
}
